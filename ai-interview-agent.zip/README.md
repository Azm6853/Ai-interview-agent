# AI Interview Agent Backend

This is the backend for the AI Interview Agent project.

## Folders
- backend: main FastAPI app and logic

## Start
```bash
uvicorn backend.main:app --reload
```