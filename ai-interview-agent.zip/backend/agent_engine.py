# LangChain agent logic: question generation, memory, follow-ups
