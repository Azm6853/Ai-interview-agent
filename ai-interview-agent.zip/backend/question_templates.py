# Prompt templates for technical, behavioral, icebreaker questions
