# Data model for interview session, response tracking
