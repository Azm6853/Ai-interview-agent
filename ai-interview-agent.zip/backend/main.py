# Entry point: FastAPI app with endpoints
